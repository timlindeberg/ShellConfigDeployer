This is a plugin based on yum plugin, but using dnf as main frontend
(from Fedora 22 onwards, yum is deprecated in favor of dnf).
 
